<!DOCTYPE html>
<html lang="zxx">
   <head>
      <title></title>
      <!--meta tags -->
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="" />
      
      <!--booststrap-->
      <!--<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">-->
      <!--//booststrap end-->
      <!--stylesheets-->
      <style>
          .btn-info {
  color: #fff;
  background-color: #fda30e;
  border-color: #fda30e;
}

      </style>
      <link href="css/offerss.css" rel='stylesheet' type='text/css' media="all">
   </head>
   <body> 
      <!-- about -->
      <section class="about py-lg-4 py-md-3 py-sm-3 py-3" id="about">
            <div class="container py-lg-5 py-md-5 py-sm-4 py-4">
               <h3 class="title text-center mb-lg-5 mb-md-4  mb-sm-4 mb-3">Best Products</h3>
               <div class="row banner-below-w3l">
                  <div class="col-lg-4 col-md-6 col-sm-6 text-center banner-agile-flowers">
                     <img src="images/sm1.jpeg" class="img-thumbnail" alt="">
                     <div class="banner-right-icon">
                        <h4 class="pt-3">Baby Toys</h4>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 text-center banner-agile-flowers">
                     <img src="images/sm1.jpeg" class="img-thumbnail" alt="">
                     <div class="banner-right-icon">
                        <h4 class="pt-3">Lite-Brite</h4>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 text-center banner-agile-flowers">
                     <img src="images/sm1.jpeg" class="img-thumbnail" alt="">
                     <div class="banner-right-icon">
                        <h4 class="pt-3">Key Toys</h4>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 mt-3 text-center banner-agile-flowers">
                     <img src="images/sm1.jpeg" class="img-thumbnail" alt="">
                     <div class="banner-right-icon">
                        <h4 class="pt-3">Play Toys</h4>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 mt-3 text-center banner-agile-flowers">
                     <img src="images/sm1.jpeg" class="img-thumbnail" alt="">
                     <div class="banner-right-icon">
                        <h4 class="pt-3">Gift Toys</h4>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-sm-6 mt-3 text-center banner-agile-flowers">
                     <!-- <img src="images/p2.jpg" class="img-thumbnail" alt="">-->
                     <div class="banner-right-icon">
                        <!-- <h4 class="pt-3">Soft Toys</h4> --> -->
                        <img src="images/p2.png" class="img-responsive" alt="" />
                                <button class="btn btn-info more-btn">View More</button>
                     </div>
                  </div>
                  <div class="toys-grids-upper">
                     <div class="about-toys-off">
                        <h2>Get Up to <span>70% Off </span>On Selected Toys</h2>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- //about -->

      <!--js working-->
      <!--//js working-->
      <!--bootstrap working-->
      <!--<script src="js/bootstrap.min.js"></script>-->
      <!-- //bootstrap working-->
   
