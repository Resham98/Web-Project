<?php
$con = Mysql_connect('localhost','id420939_kamlakar','admin@123');
Mysql_select_db('id420939_kamlakar');
?>