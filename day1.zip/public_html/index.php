<!DOCTYPE html>
<html>
<body>
<div>
<?php
    include("header.php");
?>
</div> 

<div>
<?php
    echo"abcd";
    include("slider.php");
?>    
</div>
<div>
<?php
    echo"abcd";
    include("footer.php");
?>    
</div>
</body>
</html>