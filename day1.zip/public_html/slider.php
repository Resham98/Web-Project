<html lang="en">

<!--<head>-->
<!--    <title>Slider | SC Components components.staticcodes.io</title>-->
<!--    <meta name="viewport" content="width=device-width, initial-scale=1">-->
<!--    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />-->
<!--    <link href="https://www.static-codes.com/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />-->
<!--    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.12/css/all.css" integrity="sha384-G0fIWCsCzJIMAVNQPfjH08cyYaUtMwjJwqiRKxxE/rx96Uroj1BtIQ6MLJuheaO9"-->
<!--        crossorigin="anonymous">-->
<!--        <link href="css/slidercss.css" rel="stylesheet">-->
        
<!--</head>-->

<body id="slider--14">
    <div class="banner">
        <div class="slider">
            <div class="callbacks_container">
                <ul class="rslides" id="slider3">
                    <li>
                        <div class="slider-img">
                            <img src="images/b1.jpg" class="img-responsive" alt="Fantasy World">
                        </div>
                        <div class="slider-info">
                            <h4>HE THE MEN'S STORE</h4>
                            <p>World of shoes </p>
                        </div>
                    </li>
                    <li>
                        <div class="slider-img">
                            <img src="images/b2.jpg" class="img-responsive" alt="Fantasy World">
                        </div>
                        <!--<div class="slider-info">-->
                        <!--    <h4>Girl Dragon fantasy sword wing</h4>-->
                        <!--    <p>World building is component of fantasy </p>-->
                        <!--</div>-->
                    </li>
                    <li>
                        <div class="slider-img">
                            <img src="images/b3.jpg" class="img-responsive" alt="Fantasy World">
                        </div>
                        <!--<div class="slider-info">-->
                        <!--    <h4>Danger bear guy pistol moment</h4>-->
                        <!--    <p>World building is component of fantasy </p>-->
                        <!--</div>-->
                    </li>
                </ul>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
  <!--  <script src="https://components.staticcodes.io/js/jquery-2.2.3.min.js"></script>-->
  <!--  <script src="https://components.staticcodes.io/js/responsiveslides.min.js"></script>-->

  <!--  <script>-->
  <!--      $(function () {-->
		<!--	$("#slider3").responsiveSlides({-->
		<!--		auto: true,-->
		<!--		pager: false,-->
		<!--		nav: true,-->
		<!--		speed: 500,-->
		<!--		namespace: "callbacks",-->
		<!--		before: function () {-->
		<!--			$('.events').append("<li>before event fired.</li>");-->
		<!--		},-->
		<!--		after: function () {-->
		<!--			$('.events').append("<li>after event fired.</li>");-->
		<!--		}-->
		<!--	});-->

		<!--});-->
  <!--      </script>-->
  <!--  <script src="https://components.staticcodes.io/js/bootstrap.js"></script>-->
</body>


</html>